class KeyIndicator:
    method = int

    def __init__(self, method):
        self.method = method
